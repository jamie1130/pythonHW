# PIC 16A HW1
# Name:
# Collaborators:
# Date:

import random # This is only needed in Problem 5

# Problem 1

def print_s(s):
    ''' Prints a given string.
    Args:
        s: A string.
    Returns:
        None
    '''
    print(s)

# you do not have to add docstrings for the rest of these print_s_* functions.

def print_s_lines(s):
    pass # replace with your code. 

def print_s_parts(s):
    pass # replace with your code

def print_s_some(s):
    pass # replace with your code

def print_s_change(s):
    pass # replace with your code


# Problem 2 

def make_count_dictionary(L):
    ''' Counts how many times each element in a list appears.
    Args:
        L: A list. Elements may be of different types.
    Returns:
        A dict of counts. A key is a unique element of L,
        and its corresponding value is how many times
        that element is in L.
    Example:
        L = ["a", "a", "b", "c"]
        returns {"a" : 2, "b" : 1, "c" : 1}
    '''
    pass # replace with your code


# Problem 3

def gimme_an_odd_number():
    ''' Waits for an odd number.
    Repeatedly prompts user with 'Please enter an integer.'  
    until given an odd number.
    Assume the user will only type in non-negative integers.

    Args:
        None
    Returns:
        At termination, prints and returns a list of 
        all numbers that the user has given so far.
    '''
    pass # replace with your code

# Problem 4

def get_triangular_numbers(k):
    ''' Finds the first k triangular numbers. 
    Args:
        k: A positive integer.  
    Returns:
        A list of the first k triangular numbers,
        in order. Each element is an integer.
    Example:
        k = 6
        returns [1, 3, 6, 10, 15, 21]
    '''
    pass # replace with your code


def get_consonants(s):
    ''' Finds only the consonant letters in a string.
    Args:
        s: A string that contains only lowercase alphabet letters,
        vowels, spaces, commas, and periods.
    Returns:
        A list of strings. Each element
            - is one character long,
            - is not a vowel, space, comma, nor period,
            - is in s, and
            - may appear multiple times.
        The elements appear in the same order as the letters in s.
    Example:
        s = "make it so, number one."
        returns ["m", "k", "t", "s", "n", "m", "b", "r", "n"]    
    '''
    pass # replace with your code


def get_list_of_powers(X, k):
    ''' Raise elements of a list to its powers.
    Args:
        X: A list of non-negative integers.
        k: A non-negative integer.
    Returns:
        A list of lists. The ith element is a list
        of the powers of X[i] from 0 to (and including) k, 
        in increasing order.
    Example:
        X = [5,6,7], k = 2
        returns [[1, 5, 25], [1, 6, 36], [1, 7, 49]]
    '''
    pass # replace with your code


def get_list_of_even_powers(L, k):
    ''' Raise elements of a list to its even powers.
    Args:
        X: A list of non-negative integers.
        k: A non-negative integer. May or may not be even.
    Returns:
        A list of lists. The ith element is a list
        of the EVEN powers of X[i] from 0 to (and including) k, 
        in increasing order.
    Example:
        X = [5,6,7], k = 2
        returns [[1, 25], [1, 36], [1, 49]]
    '''
    pass # replace with your code



# Problem 5

def random_walk(ub, lb):
    ''' Simulates a simple, unbiased random walk.
    Terminates when the walk's position reaches
    the upper bound or lower bound. Initial position is 0.

    Args:
        ub: An integer. Upper bound of the walk.
        lb: An integer. Lower bound of the walk.
        You can assume ub >= lb.
    Returns:
        pos: An integer. The walk's final position.
        positions: A list of integers. A log of the walk's positions, 
        including initial but excluding final position.
        steps: A list of -1s and 1s. A log of the coin flips.
    '''
    pass # replace with your code


# If you uncomment these two lines, you can run 
# the gimme_an_odd_number() function by
# running this script on your IDE or terminal. 
# Of course you can run the function in notebook as well. 
# Make sure this stays commented when you submit
# your code.
#
# if __name__ == "__main__":
#     gimme_an_odd_number()